
package dao;

import model.Category;


public interface CategoryDAO extends BaseDAO<Category> {
    
}
