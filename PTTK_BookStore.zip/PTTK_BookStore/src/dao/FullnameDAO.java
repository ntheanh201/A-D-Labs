
package dao;

import model.Fullname;


public interface FullnameDAO extends BaseDAO<Fullname>{
    
}
