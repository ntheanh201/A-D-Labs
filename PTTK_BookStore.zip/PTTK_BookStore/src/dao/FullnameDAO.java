
package dao;

import model.FullName;


public interface FullnameDAO extends BaseDAO<FullName>{
    
}
