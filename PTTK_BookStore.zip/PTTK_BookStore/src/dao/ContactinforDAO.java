
package dao;

import model.ContactInfor;


public interface ContactinforDAO  extends BaseDAO<ContactInfor>{
    
}
