
package dao;

import model.Contactinfor;


public interface ContactinforDAO  extends BaseDAO<Contactinfor>{
    
}
