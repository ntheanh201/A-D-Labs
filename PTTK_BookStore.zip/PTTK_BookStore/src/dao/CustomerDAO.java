
package dao;

import model.Customer;


public interface CustomerDAO extends BaseDAO<Customer>{
    
}
