
package dao;

import model.Shippingaddress;


public interface ShippingAddressDAO extends BaseDAO<Shippingaddress>{
    
}
