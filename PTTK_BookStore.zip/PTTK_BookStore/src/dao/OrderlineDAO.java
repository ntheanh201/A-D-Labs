
package dao;

import model.Orderline;


public interface OrderlineDAO extends BaseDAO<Orderline>{
    
}
