
package dao;

import model.Address;


public interface AddressDAO extends BaseDAO<Address>{
    
}
