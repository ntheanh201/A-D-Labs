
package dao;

import model.Wishlist;


public interface WishlistDAO extends BaseDAO<Wishlist>{
    
}
