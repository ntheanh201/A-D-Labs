
package dao;

import model.Membershiptype;


public interface MembershiptypeDAO extends BaseDAO<Membershiptype>{
    
}
