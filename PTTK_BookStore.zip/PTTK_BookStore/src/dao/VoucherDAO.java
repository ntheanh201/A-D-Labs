
package dao;

import model.Voucher;


public interface VoucherDAO extends BaseDAO<Voucher>{
    
}
