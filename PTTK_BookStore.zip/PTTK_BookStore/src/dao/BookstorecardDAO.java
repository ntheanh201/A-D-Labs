
package dao;

import model.Bookstorecard;


public interface BookstorecardDAO extends BaseDAO<Bookstorecard>{
    
}
